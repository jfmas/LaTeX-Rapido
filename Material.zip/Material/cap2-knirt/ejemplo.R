#### Código de R Guía LaTeX

# Importa el archivo csv
tabla <- read.csv("tabla1.csv")
print(tabla)

# Calcula el coeficiente de correlación entre PIB y Esperanza de vida
cor1 <- cor(tabla$PIB,tabla$Esperanza)
print(cor1)
# Calcula el coeficiente de correlación entre Gini y Esperanza de vida
cor2 <- cor(tabla$Gini,tabla$Esperanza)
print(cor2)

# Elabora un diagrama de dispersión
plot(tabla$Gini,tabla$Esperanza, xlab = "Índice de Gini",
     ylab = "Esperanza de vida",xlim=c(40,63))
text(tabla$Gini,tabla$Esperanza,labels=tabla$pais, cex= 0.7, pos=4)

# Elabora boxplots
par(mfrow=c(1,3))
boxplot(tabla$PIB, main = "PIB")
boxplot(tabla$Gini, main = "Gini")
boxplot(tabla$Esperanza, main = "Esperanza")

